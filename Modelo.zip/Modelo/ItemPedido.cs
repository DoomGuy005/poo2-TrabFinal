﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class ItemPedido
    {
        public int quantidade;
        public Peça peça;
        public decimal preco;
    }
}
