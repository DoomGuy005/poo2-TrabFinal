﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class Cliente
    {
        public string nome;
        public string email;
        public string fone;
        public DateTime nascimento;
    }
}
